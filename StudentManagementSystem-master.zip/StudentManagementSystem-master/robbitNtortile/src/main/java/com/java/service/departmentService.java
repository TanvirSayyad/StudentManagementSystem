package com.java.service;




import com.java.entity.Department;
import com.java.entity.Student;

public interface departmentService {
	
	
	Department saveDepartment(Department department);
	


}
